/**
 * @name Hide Folios Data
 * @file Configuration pour le masquage des folios
 */

export default {
  "version": "1.0",
  "pages": "81-83"
};